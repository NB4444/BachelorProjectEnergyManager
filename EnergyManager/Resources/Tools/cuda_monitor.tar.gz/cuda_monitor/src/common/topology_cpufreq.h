state_t topology_cpufreq_getbase(uint cpu, ulong *freq_base);
